let user="";
function myfun1()
            { 
                console.log(
                    "hii"
                );
                let x=document.getElementById("user").value;
              let y=document.getElementById("email").value;
              let z=document.getElementById("no").value;
              let a=document.getElementById("pass").value;

                if(x==""){
                    alert("Enter a details");
                }
                else if(y==""){
                    alert("Enter a details");
                }
                else if(z=="" || z.length<10 || z.length>10){
                    alert("Enter a details");
                }
                else if(a=="" ){
                    alert("Enter a details");
                }
                else{
                    let flag=false;
                    for(let i=0;i<y.length;i++){
                       if(y.charAt(i)==='@'){
                             flag=true;
                        }
                        if(!flag){
                           alert("Enter a email correctly...");
                     
                        }}
                user=x;
                console.log(user);
                debugger;
                window.open("C://Users//Admin//Desktop//Crypto_Prediction//crp//webAPI.py");
                }   
              }

            
            function myfun2()
            {
                open("crypto_page-2.html");
            }
            
		function fun(){
			if(user!="")
				window.open("index.html");
			
		}
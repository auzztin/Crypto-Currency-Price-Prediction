import tensorflow as tf
import numpy as np
from flask import Flask,redirect,url_for,render_template,request
import pandas as pd 
from sklearn.preprocessing import MinMaxScaler
from datetime import datetime as dt
import webbrowser
#Fetch historical stock data
app = Flask(__name__)
@app.route('/update_content', methods=['POST'])

def update_content():
    new_content = request.form['new_content']
    ticker = new_content 
    # data = yf.download(ticker, start=start_date, end=end_date)

    app=Flask(__name__)

    match ticker:
        case "ADA":
            MODEL = tf.keras.models.load_model(f"C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/Models/ADA.keras" )
            data = pd.read_csv('C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/CSV/ADA-USD.csv')
            data = data[['Close']]
            dataset = data.values.astype('float32')
            scaler = MinMaxScaler(feature_range=(0, 1))
            scaled_data = scaler.fit_transform(dataset)
            test_size = int(len(scaled_data))
            test_data = scaled_data
            inputs = data[len(data) - len(test_data):].values
            inputs = inputs.reshape(-1, 1)
            inputs = scaler.transform(inputs)
            window_size = 60
            X_test = []
            for i in range(window_size, len(inputs)):
                X_test.append(inputs[i - window_size:i, 0])
            X_test = np.array(X_test)
            X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1]))

        case "ETH":
            MODEL = tf.keras.models.load_model(f"C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/Models/ETH.keras" )
            data = pd.read_csv('C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/CSV/ETH-USD.csv')
            data = data[['Close']]
            dataset = data.values.astype('float32')
            scaler = MinMaxScaler(feature_range=(0, 1))
            scaled_data = scaler.fit_transform(dataset)
            test_size = int(len(scaled_data))
            test_data = scaled_data
            inputs = data[len(data) - len(test_data):].values
            inputs = inputs.reshape(-1, 1)
            inputs = scaler.transform(inputs)
            window_size = 60
            X_test = []
            for i in range(window_size, len(inputs)):
                X_test.append(inputs[i - window_size:i, 0])
            X_test = np.array(X_test)
            X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1]))
        case "XRP":
            MODEL = tf.keras.models.load_model(f"C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/Models/XRP.keras")
            data = pd.read_csv('C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/CSV/XRP-USD.csv')
            data = data[['Close']]
            dataset = data.values.astype('float32')
            scaler = MinMaxScaler(feature_range=(0, 1))
            scaled_data = scaler.fit_transform(dataset)
            test_size = int(len(scaled_data))
            test_data = scaled_data
            inputs = data[len(data) - len(test_data):].values
            inputs = inputs.reshape(-1, 1)
            inputs = scaler.transform(inputs)
            window_size = 60
            X_test = []
            for i in range(window_size, len(inputs)):
                X_test.append(inputs[i - window_size:i, 0])
            X_test = np.array(X_test)
            X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1]))
        case "LTC":
            MODEL = tf.keras.models.load_model(f"C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/Models/LTC.keras" )
            data = pd.read_csv('C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/CSV/LTC-USD.csv')
            data = data[['Close']]
            dataset = data.values.astype('float32')
            scaler = MinMaxScaler(feature_range=(0, 1))
            scaled_data = scaler.fit_transform(dataset)
            test_size = int(len(scaled_data))
            test_data = scaled_data
            inputs = data[len(data) - len(test_data):].values
            inputs = inputs.reshape(-1, 1)
            inputs = scaler.transform(inputs)
            window_size = 60
            X_test = []
            for i in range(window_size, len(inputs)):
                X_test.append(inputs[i - window_size:i, 0])
            X_test = np.array(X_test)
            X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1]))
        case "BTC":
            MODEL = tf.keras.models.load_model(f"C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/Models/BTC.keras" )
            data = pd.read_csv('C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/CSV/BTC-USD.csv')
            data = data[['Close']]
            dataset = data.values.astype('float32')
            scaler = MinMaxScaler(feature_range=(0, 1))
            scaled_data = scaler.fit_transform(dataset)
            test_size = int(len(scaled_data))
            test_data = scaled_data
            inputs = data[len(data) - len(test_data):].values
            inputs = inputs.reshape(-1, 1)
            inputs = scaler.transform(inputs)
            window_size = 60
            X_test = []
            for i in range(window_size, len(inputs)):
                X_test.append(inputs[i - window_size:i, 0])
            X_test = np.array(X_test)
            X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1]))
        case "FTC":
            MODEL = tf.keras.models.load_model(f"C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/Models/FTC.keras" )
            data = pd.read_csv('C:/Users/Pranesh.A/Desktop/Crypto_Prediction/crp/templates/CSV/FTC-USD.csv')
            data = data[['Close']]
            dataset = data.values.astype('float32')
            scaler = MinMaxScaler(feature_range=(0, 1))
            scaled_data = scaler.fit_transform(dataset)
            test_size = int(len(scaled_data))
            test_data = scaled_data
            inputs = data[len(data) - len(test_data):].values
            inputs = inputs.reshape(-1, 1)
            inputs = scaler.transform(inputs)
            window_size = 60
            X_test = []
            for i in range(window_size, len(inputs)):
                X_test.append(inputs[i - window_size:i, 0])
            X_test = np.array(X_test)
            X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1]))
    
    predictions = MODEL.predict(X_test)
    predictions = scaler.inverse_transform(predictions)
    predictions = predictions.tolist()
    msg =  predictions[-1]
    return msg
        
@app.route('/', methods=['GET', 'POST'])
def redirect_to_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('crypto_index.html')

@app.route('/crypto_about.html', methods=['GET', 'POST'])
def crypto_about_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('crypto_about.html')

@app.route('/crypto_learnmore.html', methods=['GET', 'POST'])
def crypto_learnmore_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('crypto_learnmore.html')

@app.route('/crypto_selectcoin.html', methods=['GET', 'POST'])
def crypto_select_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('crypto_selectcoin.html')

@app.route('/crypto_page-2.html', methods=['GET', 'POST'])
def crypto_page_2_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('crypto_page-2.html')

@app.route('/crypto_form.html', methods=['GET', 'POST'])
def crypto_form_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('crypto_form.html')

@app.route('/index.html', methods=['GET', 'POST'])
def index_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('index.html')

@app.route('/FTC_select.html', methods=['GET', 'POST'])
def ftc_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('FTC_select.html')

@app.route('/LTC_select.html', methods=['GET', 'POST'])
def Ltc_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('LTC_select.html')

@app.route('/XRP_select.html', methods=['GET', 'POST'])
def XRP_select_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('XRP_select.html')

@app.route('/ETH_select.html', methods=['GET', 'POST'])
def eth_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('ETH_select.html')

@app.route('/ADA_select.html', methods=['GET', 'POST'])
def ada_select_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('ADA_select.html')


@app.route('/crypto_index.html', methods=['GET', 'POST'])
def crypto_index_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('crypto_index.html')

@app.route('/btclive.html', methods=['GET', 'POST'])
def btclive_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('btclive.html')

@app.route('/ada.html', methods=['GET', 'POST'])
def ada_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('ada.html')

@app.route('/ethlive.html', methods=['GET', 'POST'])
def ethlive_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('ethlive.html')

@app.route('/ftclive.html', methods=['GET', 'POST'])
def ftclive_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('ftclive.html')

@app.route('/ltclive.html', methods=['GET', 'POST'])
def ltclive_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('ltclive.html')

@app.route('/xrp.html', methods=['GET', 'POST'])
def xrp_html():
    if request.method == 'POST':
        selected_option = request.form.get('option')
        return f"You selected: {selected_option}"
    return  render_template('xrp.html')


if __name__=="__main__":
    app.run(debug=True)
